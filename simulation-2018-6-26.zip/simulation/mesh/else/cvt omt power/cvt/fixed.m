%%balance the computation power and load fraction
%