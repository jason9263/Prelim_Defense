clc
%% show 2*2
% coredraw(2,2);
% %% show 2*3
% coredraw(2,3);
% %% show 2*n
% coredraw(2,10);
% %% show 3*n
% coredraw(3,8);
% %% show 4*10
% coredraw(4,10);
%%
coredraw(5,5);
clc