function [B] = sigmaB(sigma,m,n)

B = zeros(m+n-1,1);

B(1) = 1;

end
