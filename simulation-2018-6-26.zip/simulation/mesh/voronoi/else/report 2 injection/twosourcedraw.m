clc
twocoredraw(5,5);